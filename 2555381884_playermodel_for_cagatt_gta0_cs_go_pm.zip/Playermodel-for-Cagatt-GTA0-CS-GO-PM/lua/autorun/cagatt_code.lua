player_manager.AddValidModel( "Cagatt", "models/player/cagatt.mdl" )
player_manager.AddValidHands( "Cagatt", "models/weapons/c_arms_cagatt.mdl", 0, "10000000" )
